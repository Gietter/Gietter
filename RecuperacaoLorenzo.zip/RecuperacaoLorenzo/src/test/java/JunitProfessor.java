import br.com.lorenzo.Professor;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;
public class JunitProfessor {


    @Test
    public void test(){
        Professor professor = new Professor(2000);
        assertEquals(2000, professor.getSalario());
    }
}
