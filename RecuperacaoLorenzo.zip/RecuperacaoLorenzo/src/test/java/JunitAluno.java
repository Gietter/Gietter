import br.com.lorenzo.Aluno;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class JunitAluno {

    @Test
    public void teste(){
        Aluno aluno = new Aluno("123123", 9.2);

        aluno.setMatricula("123123");
        assertEquals("123123", aluno.getMatricula());
    }
}
