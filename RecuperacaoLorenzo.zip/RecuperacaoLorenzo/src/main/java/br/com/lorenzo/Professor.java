package br.com.lorenzo;

public class Professor extends Pessoa {
    private int salario;

    public int getSalario() {
        return salario;
    }

    public void setSalario(int salario) {
        this.salario = salario;
    }

    public Professor(int salario) {
        this.salario = salario;
    }
}
