package br.com.lorenzo;



public class Aluno extends Pessoa {
        private String matricula;
        private double media;

    public Aluno(String matricula, double media) {
        this.matricula = matricula;
        this.media = media;
    }

    public String getMatricula() {
            return matricula;
        }
        public void setMatricula(String matricula) {
            this.matricula = matricula;
        }
        public double getMedia() {
            return media;
        }
        public void setMedia(double media) {
            this.media = media;
        }

        public void calcularMedia() {

        }


        @Override
        public String toString() {
            return "Aluno [matricula=" + matricula + ", media=" + media + "]";
        }




    }


