package com.Lorenzo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LorenzoApplicationTests {

	@Test
	void contextLoads() {
	}

}
