package com.Lorenzo.Service;

public interface ProdutoService {
}
