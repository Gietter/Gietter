package com.Lorenzo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LorenzoApplication {

	public static void main(String[] args) {
		SpringApplication.run(LorenzoApplication.class, args);
	}

}
