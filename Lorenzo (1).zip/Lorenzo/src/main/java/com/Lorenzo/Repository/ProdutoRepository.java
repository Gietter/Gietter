package com.Lorenzo.Repository;

public interface ProdutoRepository {
}
