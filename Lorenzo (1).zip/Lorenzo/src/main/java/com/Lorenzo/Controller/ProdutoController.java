package com.Lorenzo.Controller;

import org.springframework.stereotype.Controller;

@Controller
public class ProdutoController{
}
